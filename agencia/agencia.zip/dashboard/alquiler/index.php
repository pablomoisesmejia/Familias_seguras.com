<?php
require_once("../../app/views/dashboard/templates/page.class.php");
Page::templateHeader("Propiedades en alquiler");
require_once("../../app/controllers/dashboard/alquiler/index_controller.php");
Page::templateFooter();
?>