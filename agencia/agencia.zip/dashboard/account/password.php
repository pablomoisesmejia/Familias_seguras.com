<?php
require_once("../../app/views/dashboard/templates/page.class.php");
Page::templateHeader("Cambiar clave");
require_once("../../app/controllers/dashboard/account/password_controller.php");
Page::templateFooter();
?>