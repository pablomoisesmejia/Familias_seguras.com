<?php
require_once("../../app/views/dashboard/templates/page.class.php");
Page::templateHeader("Propiedades en venta");
require_once("../../app/controllers/dashboard/venta/index_controller.php");
Page::templateFooter();
?>