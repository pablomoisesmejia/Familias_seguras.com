<?php
require_once("../../app/views/dashboard/templates/page.class.php");
Page::templateHeader("Gestionar modelos de vehiculos");
require_once("../../app/controllers/dashboard/modelo/index_controller.php");
Page::templateFooter();
?>