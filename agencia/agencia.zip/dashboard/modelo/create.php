<?php
require_once("../../app/views/dashboard/templates/page.class.php");
Page::templateHeader("Crear modelos de vehiculos");
require_once("../../app/controllers/dashboard/modelo/create_controller.php");
Page::templateFooter();
?>