<form method='post' autocomplete='off'>
	<div class='row center-align'>
		<h4>Una categoría será borrada ¿está seguro?</h4>
		<a href='index.php' class='btn waves-effect grey tooltipped' data-tooltip='Cancelar'><i class='material-icons'>cancel</i></a>
		<button type='submit' name='eliminar' class='btn waves-effect red tooltipped' data-tooltip='Eliminar'><i class='material-icons'>remove_circle</i></button>
	</div>
</form>