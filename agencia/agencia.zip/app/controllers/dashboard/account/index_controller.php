<?php
require_once("../../app/views/dashboard/account/index_view.php");
?>