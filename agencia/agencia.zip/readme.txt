Este ejemplo ha sido desarrollado con las siguientes herramientas:
- XAMPP v5.6.15 x32
- Materialize v0.100.2
- jQuery v3.2.1

Inicio del sitio privado:
    localhost/dashboard/account/

Inicio del sitio público:
    localhost/public/