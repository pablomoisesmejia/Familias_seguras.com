<!-- Efecto parallax con una altura de 300px -->
<div class='parallax-container'>
	<div class='parallax'><img src='../web/img/parallax/img01.jpg'></div>
</div>