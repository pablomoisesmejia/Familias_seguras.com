<div class='slider'>
    <ul class='slides'>
        <li>
            <img src='../web/img/slider/img01.jpg' alt='Foto01'>
            <div class='caption center-align'>
                <h2>¿Sabías que...?</h2>
                <h4 class='white-text'>El café reduce el riesgo de padecer Alzheimer.</h4>
            </div>
        </li>
        <li>
            <img src='../web/img/slider/img02.jpg' alt='Foto02'>
            <div class='caption left-align'>
                <h2>¿Preocupado por tu peso?</h2>
                <h4>El café contribuye a reducir esos kilos de más.</h4>
            </div>
        </li>
        <li>
            <img src='../web/img/slider/img03.jpg' alt='Foto03'>
            <div class='caption right-align'>
                <h2>¿Sabías que...?</h2>
                <h4 class='white-text'>El café reduce el riesgo de cáncer.</h4>
            </div>
        </li>
        <li>
            <img src='../web/img/slider/img04.jpg' alt='Foto04'>
            <div class='caption center-align'>
                <h2>¿Quieres lucir radiante?</h2>
                <h4 class='white-text'>El café ayuda a tener una piel más perfecta.</h4>
            </div>
        </li>
    </ul>
</div>