<!-- Términos y condiciones -->
<div id='terminos' class='modal'>
	<div class='modal-content'>
		<h4 class='center-align'>TÉRMINOS Y CONDICIONES</h4>
		<p>Nuestra empresa ofrece los mejores productos a nivel nacional con una calidad garantizada y...</p>
	</div>
	<div class='divider'></div>
	<div class='modal-footer'>
		<a href='#!' class='modal-action modal-close btn waves-effect'><i class='material-icons'>done</i></a>
	</div>
</div>

<!-- Misión -->
<div id='mision' class='modal'>
	<div class='modal-content'>
		<h4 class='center-align'>MISIÓN</h4>
		<p>Ofrecer los mejores productos a nivel nacional para satisfacer a nuestros clientes y...</p>
	</div>
	<div class='divider'></div>
	<div class='modal-footer'>
		<a href='#!' class='modal-action modal-close btn waves-effect'><i class='material-icons'>done</i></a>
	</div>
</div>

<!-- Visión -->
<div id='vision' class='modal'>
	<div class='modal-content'>
		<h4 class='center-align'>VISIÓN</h4>
		<p>Ser la empresa lider en la región ofreciendo productos de calidad a precios accesibles y...</p>
	</div>
	<div class='divider'></div>
	<div class='modal-footer'>
		<a href='#!' class='modal-action modal-close btn waves-effect'><i class='material-icons'>done</i></a>
	</div>
</div>

<!-- Valores -->
<div id='valores' class='modal'>
	<div class='modal-content center-align'>
		<h4>VALORES</h4>
		<p>Responsabilidad</p>
		<p>Honestidad</p>
		<p>Seguridad</p>
		<p>Calidad</p>
	</div>
	<div class='divider'></div>
	<div class='modal-footer'>
		<a href='#!' class='modal-action modal-close btn waves-effect'><i class='material-icons'>done</i></a>
	</div>
</div>