<?php
require_once("../../app/views/dashboard/templates/page.class.php");
Page::templateHeader("Cootizaciones");
require_once("../../app/controllers/dashboard/usuario/create_cuadro_controller.php");
Page::templateFooter();
?>