$(document).ready(function(){

    $('.modal').modal();
    cargarMarcas();
    function cargarMarcas()
    {
        $.ajax({
            url: '../../app/controllers/public/index/marcas_controller.php',
            dataType:'json',
            success: function(marcas)
            {
                $('#marca_vehiculo').empty();
                $('#marca_vehiculo').append('<option value="" disabled selected>Seleccione una marca</option>');
                if(marcas != '')
                {
                    i = 0;
                    for(i; i<marcas.length; i++)
                    {
                        var option = '';
                        option = option.concat(
                            '<option value="'+marcas[i].PK_id_marca_vehiculo+'">'+marcas[i].marca_vehiculo+'</option>'
                        );
                        $('#marca_vehiculo').append(option);
                    }
                    $('select').material_select();
                }
            }
        });
    }

    cargarOrigenVehiculo();
    function cargarOrigenVehiculo()
    {
        $.ajax({
            url: '../../app/controllers/public/index/origenes_vehiculo_controller.php',
            dataType: 'json',
            success:  function(origenes)
            {
                $('#origen_vehiculo').empty();
                $('#origen_vehiculo').append('<option value="" disabled selected>Seleccione una opción</option>');
                if(origenes != '')
                {
                    i = 0;
                    for(i; i<origenes.length; i++)
                    {
                        var option = '';
                        option = option.concat(
                            '<option value="'+origenes[i].PK_id_origen_vehiculo+'">'+origenes[i].origen_vehiculo+'</option>'
                        );
                        $('#origen_vehiculo').append(option);
                    }
                    $('select').material_select();
                }
            }
        });
    }

    $('#marca_vehiculo').on('change', function(){
        id_marca = $('#marca_vehiculo').val();
        $.ajax({
            type:'POST',
            url: '../../app/controllers/public/index/modelos_controller.php',
            data:{id_marca:id_marca},
            dataType: 'json',
            success:function(modelos)
            {
                $('#modelo_vehiculo').empty(); 
                console.log(modelos);

                if(modelos != '')
                {
                    $('#modelo_vehiculo').append('<option value="" selected disabled>Seleccione el modelo del vehiculo</option>');
                    i = 0;
                    for(i; i<modelos.length; i++)
                    {
                        var option = "";
                        option = option.concat(
                            '<option value="'+modelos[i].PK_id_modelo_vehiculo+'">'+modelos[i].modelos_vehiculo+'</option>'
                        );
                        $('#modelo_vehiculo').append(option);
                    }
                    $('select').material_select();
                }
                else
                {
                    $('#modelo_vehiculo').empty();
                    $('#modelo_vehiculo').append('<option value="" disabled selected>No se encontraron modelos para la marca seleccionada</option>'); 
                    $('select').material_select();
                }
            }
        });
    });


    $('#agregar').click(function(){
        marca_vehiculo = $('#marca_vehiculo').val();
        modelo_vehiculo = $('#modelo_vehiculo').val();
        anio = $('#anio').val();
        placa = $('#placa').val();
        origen_vehiculo = $('#origen_vehiculo').val();
        valor_vehiculo = $('#valor_vehiculo').val();

        nombre_marca = $('#marca input.select-dropdown').val();
        nombre_modelo = $('#modelo input.select-dropdown').val();
        console.log(nombre_marca);
        if(marca_vehiculo != null)
        {
            if(modelo_vehiculo != null)
            {
                if(anio != '')
                {
                    if(placa != '')
                    {
                        if(origen_vehiculo != null)
                        {
                            if(valor_vehiculo != '')
                            {
                                
                            }
                            else
                            {
                                AlertaSweet(3, 'Ingrese el valor del vehiculo');
                            }
                        }
                        else
                        {
                            AlertaSweet(3, 'Seleccione el origen del vehiculo');
                        }
                    }
                    else
                    {
                        AlertaSweet(3, 'Ingrese la placa del vehiculo');
                    }
                }
                else
                {
                    AlertaSweet(3, 'Ingrese el año del vehiculo');
                }
            }
            else
            {
                AlertaSweet(3, 'Seleccione el modelo del vehiculo');
            }
        }
        else
        {
            AlertaSweet(3, 'Seleccione la marca del vehiculo');
        }
    });
});

var marca_vehiculo = '';
var modelo_vehiculo = '';
var anio = '';
var placa = '';
var origen_vehiculo = '';
var valor_vehiculo = '';

var tipo_seguro = 4;

function Paso1()
{
    marca_vehiculo = $('#marca_vehiculo').val();
    modelo_vehiculo = $('#modelo_vehiculo').val();
    anio = $('#anio').val();
    placa = $('#placa').val();
    origen_vehiculo = $('#origen_vehiculo').val();
    valor_vehiculo = $('#valor_vehiculo').val();

    if(marca_vehiculo != null)
    {
        if(modelo_vehiculo != null)
        {
            if(anio != '')
            {
                if(placa != '')
                {
                    if(origen_vehiculo != null)
                    {
                        if(valor_vehiculo != '')
                        {
                            siguiente2();
                        }
                        else
                        {
                            AlertaSweet(3, 'Ingrese el valor del vehiculo');
                        }
                    }
                    else
                    {
                        AlertaSweet(3, 'Seleccione el origen del vehiculo');
                    }
                }
                else
                {
                    AlertaSweet(3, 'Ingrese la placa del vehiculo');
                }
            }
            else
            {
                AlertaSweet(3, 'Ingrese el año del vehiculo');
            }
        }
        else
        {
            AlertaSweet(3, 'Seleccione el modelo del vehiculo');
        }
    }
    else
    {
        AlertaSweet(3, 'Seleccione la marca del vehiculo');
    }
}