<h1 class="form_sub_title">Seguro De Vehículo</h1>


<form id="form_coti_auto">
       
        <div class='row'>
            <div class='input-field col s12 '>
                <input id="numero_licencia" type="number" class="validate" required/>
                <label class="" for="numero_licencia">Número de Licencia</label>
            </div>
            <p class="frm_p_text">Necesitamos tu número de licencia para poder brindarte la cotización del seguro de vehículos.</p>
        </div>
         
        

            <a id="return_btn" class="continuar">Continuar</a> 
</form>


