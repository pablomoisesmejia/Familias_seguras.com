<div id='lateral_bar_style'>
    <div id="lateral_bar_space"></div>
    <a onclick="section_selected=1; show_info_section();" class="lateral_btn_style">
        <i class='material-icons prefix'>home</i>
    </a>
    <div class="divider_btn_H"> </div>   
    <a onclick="section_selected=2; show_info_section();" class="lateral_btn_style">
        <i class='material-icons prefix'>dashboard</i>
    </a>
    <div class="divider_btn_H"> </div>   
    <a onclick="section_selected=3; show_info_section();" class="lateral_btn_style">
        <i class='material-icons prefix'>info</i>
    </a>
    <div class="divider_btn_H"> </div>   
    <a onclick="section_selected=4; show_info_section();" class="lateral_btn_style">
        <i class='material-icons prefix'>message</i>   
    </a>
    <div class="divider_btn_H"> </div>  

    <!-- -->
    <div class="hide-on-large-only" id="contactanos_lateral">
        <a id="tel_btn_lateral" href="tel:+50322607851" class="lateral_btn_style">
            <i class='material-icons prefix'>phone</i>   
        </a>
        <div class="divider_btn_H"> </div>  
        <a href="https://www.facebook.com/familiasseguras/" class="lateral_btn_style">
            <img class="lateral_icons" src="../../web/img/icon/fb_icon.png" alt="facebook">
        </a>
        <div class="divider_btn_H"> </div>  
        <a id="wha_btn_lateral" href="whatsapp://send/?phone=50377280640&text=Me%20Gustaria%20obtener%20una%20cotizacion%20sobre%20los%20seguros%20que%20ofrecen." class="lateral_btn_style ">
            <img class="lateral_icons" src="../../web/img/icon/wha_icon.png" alt="whatsapp">
        </a>
        
         <a href="https://www.instagram.com/" class="lateral_btn_style">
                    <img class="lateral_icons" src="../../web/img/icon/insta_icon.png" alt="instagram">
                </a>
    
    </div>

</div>