<div id="view_email_send">
    <img id="confirmations_icon" src="../../web/img/icon/email_send.png" >
   <h3 style="font-size:1.8em;">¡La cotización ha sido exitosa!</h3> 
   <p>Revisa tu correo electrónico en las proximas 24 Horas para ver la cotización.</p>

   <a onclick=" " href="" id="return_btn">Regresar</a> 
</div>