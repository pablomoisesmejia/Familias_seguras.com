<?php
require '../../app/views/public/index/index_view.php';
?>