<?php
require_once("app/views/page.class.php");
Page::templateHeader_login("Familias Seguras");
require_once("app/views/index_view.php");
Page::templateFooter_login();
?>