<!-- content generated with JS -->  
<div class="container" style="margin:  10%; padding: 10em;">
	<h3 style="display:none;" id='name'>Andres </h3> 
		<div style="">
			<img src="framework/images/imgblack.png" >
			<h4 id='clockyt'><?php print(date('h:i A')) ?> <i class='material-icons prefix' style="color:rgb(99, 99, 99);">access_alarm</i></h4>
			<h4  style="display:none;" id='horadedia'><?php print(date('H')) ?></h4>
		</div>
	<h3 id='welcom_text' class=''>Bienvenido al dashboard de sabelofacil</h3> 
	<img src onerror='bienvenida_al_sistema();'>
</div>
