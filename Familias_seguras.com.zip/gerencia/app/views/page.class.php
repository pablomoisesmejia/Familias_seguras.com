<?php

require_once("app/models/database.class.php");
require_once("app/helpers/validator.class.php");
require_once("app/helpers/component.class.php");


class Page extends Component{
	//este es el header
	public static function templateHeader_login($title){
	    //session_start();
		ini_set('date.timezone','America/El_Salvador');
        print("
        <!DOCTYPE html>
        <html lang='es'>
        <head>
            <title>Login V1</title>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1'>
        <!--===============================================================================================-->	
            <link rel='icon' type='image/png' href='fs_ico.ico'/>
        <!--===============================================================================================-->
            <link rel='stylesheet' type='text/css' href='framework/vendor/bootstrap/css/bootstrap.min.css'>
        <!--===============================================================================================-->
            <link rel='stylesheet' type='text/css' href='framework/fonts/font-awesome-4.7.0/css/font-awesome.min.css'>
        <!--===============================================================================================-->
            <link rel='stylesheet' type='text/css' href='framework/vendor/animate/animate.css'>
        <!--===============================================================================================-->	
            <link rel='stylesheet' type='text/css' href='framework/vendor/css-hamburgers/hamburgers.min.css'>
        <!--===============================================================================================-->
            <link rel='stylesheet' type='text/css' href='framework/vendor/select2/select2.min.css'>
        <!--===============================================================================================-->
            <link rel='stylesheet' type='text/css' href='framework/css/util.css'>
            <link rel='stylesheet' type='text/css' href='framework/css/main.css'>
        <!--===============================================================================================-->
        </head>
        <body>

			 ");
	}
	public static function templateHeader($title){
	    //session_start();
		ini_set('date.timezone','America/El_Salvador');
        print("

                <!DOCTYPE html>
                <html>
                  <head>
                    <!--Import Google Icon Font-->
                    <link href='https://fonts.googleapis.com/icon?family=Material+Icons' rel='stylesheet'>
                    <title>Familias seguras</title>
                    <link rel='icon' type='image/png' href='fs_ico.ico'/>
                    <!--Import materialize.css-->
                    <link type='text/css' rel='stylesheet' href='framework/css/materialize.min.css'  media='screen,projection'/>
              
                    <!--Let browser know website is optimized for mobile-->
                    <meta name='viewport' content='width=device-width, initial-scale=1.0'/>
                  </head>

                  <nav>
                  <div class='nav-wrapper'>
                    <a href='#!' class='brand-logo'>Logo</a>
                    <a href='#' data-activates='mobile-demo' class='button-collapse'><i class='material-icons'>menu</i></a>
                    <ul class='right hide-on-med-and-down'>
                      <li><a href='sass.html'>Sass</a></li>
                      <li><a href='badges.html'>Components</a></li>
                      <li><a href='collapsible.html'>Javascript</a></li>
                      <li><a href='mobile.html'>Mobile</a></li>
                    </ul>
                    <ul class='side-nav' id='mobile-demo'>
                      <li><a href='sass.html'>Sass</a></li>
                      <li><a href='badges.html'>Components</a></li>
                      <li><a href='collapsible.html'>Javascript</a></li>
                      <li><a href='mobile.html'>Mobile</a></li>
                    </ul>
                  </div>
                </nav>

            
            



            

		
			 ");
	}

	//aqui ponemos el footer y sus referencias
	public static function templateFooter_login(){
		print("
        <!--===============================================================================================-->	
        <script src='framework/vendor/jquery/jquery-3.2.1.min.js'></script>
        <!--===============================================================================================-->
        <script src='framework/vendor/bootstrap/js/popper.js'></script>
        <script src='framework/vendor/bootstrap/js/bootstrap.min.js'></script>
        <!--===============================================================================================-->
        <script src='framework/vendor/select2/select2.min.js'></script>
        <!--===============================================================================================-->
        <script src='framework/vendor/tilt/tilt.jquery.min.js'></script>
        <script >
            $('.js-tilt').tilt({
                scale: 1.1
            })
        </script>
        <!--===============================================================================================-->
        <script src='framework/js/main.js'></script>
        </body>
        </html>
		");
	}

	//esta es la barra del lado
	public  static function templatefooter_basic(){
        print("


        <body>
        <!--Import jQuery before materialize.js-->
        <script type='text/javascript' src='https://code.jquery.com/jquery-3.2.1.min.js'></script>
        <script type='text/javascript' src='framework/js/materialize.min.js'></script>
        <script type='text/javascript' src='framework/js/funciones.js'></script>
      </body>
    </html>


	
		");
	}
}
?>