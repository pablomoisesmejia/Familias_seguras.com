<?php
    include("database.class.php");

    $query = "SELECT USU.nombres, usu.apellidos, soli.PK_id_solicitud, soli.fecha_reparticion, soli.hora_reparticion
            FROM solicitudes SOLI, empleados EMPLE, usuarios USU
            WHERE
            SOLI.FK_id_empleado=EMPLE.PK_id_empleado AND 
            EMPLE.FK_id_usuario=USU.PK_id_usuario
            AND SOLI.FK_id_estado_solicitud=1";

	if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }
?>