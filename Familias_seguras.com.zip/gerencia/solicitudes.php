<?php
require_once("app/views/page.class.php");
Page::templateHeader("Sitio privado");
require_once("app/views/soli_view.php");
Page::templatefooter_basic();
?>